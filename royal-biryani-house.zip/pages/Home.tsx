
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Star, Truck, ShieldCheck, Heart, MapPin } from 'lucide-react';
import { DISHES, REVIEWS } from './constants';

const Home: React.FC = () => {
  const signatureDishes = DISHES.filter(d => d.isSignature);

  // Using a high-quality, professional culinary photo for the background
  // This replaces the unreliable AI generation to ensure instant loading and brand consistency
  const HERO_IMAGE_URL = "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&q=80&w=2000";

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-white overflow-hidden bg-neutral-900">
        {/* Background Image Wrapper */}
        <div className="absolute inset-0 z-0">
          <img 
            src={HERO_IMAGE_URL} 
            alt="Royal Biryani House Hero" 
            className="w-full h-full object-cover object-center scale-105 animate-subtle-zoom transition-opacity duration-1000 opacity-100"
          />
          {/* 45% Black Overlay for Text Readability */}
          <div className="absolute inset-0 bg-black/45 z-10"></div>
          {/* Subtle Gradient for depth */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60 z-20"></div>
        </div>

        <div className="relative z-30 text-center max-w-4xl px-4 animate-fade-in-up">
          <div className="space-y-6">
            <span className="inline-block px-5 py-2 bg-saffron text-royal-red font-bold text-xs uppercase tracking-[0.4em] rounded-full shadow-lg transform hover:scale-105 transition-transform cursor-default">
              The Finest in New Delhi
            </span>
            <h1 className="text-5xl md:text-8xl font-black mb-6 leading-tight drop-shadow-2xl">
              Royal Biryani <br/>
              <span className="text-saffron italic font-serif">House</span>
            </h1>
            <p className="text-lg md:text-2xl text-white/90 mb-10 max-w-2xl mx-auto font-medium drop-shadow-md">
              Experience the authentic legacy of Hyderabadi flavors, slow-cooked to perfection with royal tradition.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-5 pt-4">
              <Link 
                to="/menu" 
                className="group w-full sm:w-auto px-12 py-5 bg-royal-red text-white rounded-full font-bold text-lg hover:bg-red-800 transition-all shadow-2xl hover:shadow-red-900/40 flex items-center justify-center gap-2"
              >
                Order Now <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/contact" 
                className="w-full sm:w-auto px-12 py-5 bg-white/10 backdrop-blur-md text-white border border-white/30 rounded-full font-bold text-lg hover:bg-white hover:text-royal-red transition-all"
              >
                Book a Table
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-70 z-30">
           <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center pt-2">
              <div className="w-1.5 h-1.5 bg-saffron rounded-full"></div>
           </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Why Dine With Us?</h2>
            <div className="w-24 h-1.5 bg-saffron mx-auto rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: <Heart className="text-royal-red" />, title: 'Authentic Recipes', desc: 'Generations-old Hyderabadi recipes cooked fresh daily.' },
              { icon: <MapPin className="text-royal-red" />, title: 'Local Favorite', desc: 'A trusted culinary landmark in Jasola & Jamia Nagar.' },
              { icon: <Truck className="text-royal-red" />, title: 'Fast Delivery', desc: 'Piping hot meals delivered to your doorstep within minutes.' },
              { icon: <ShieldCheck className="text-royal-red" />, title: 'Quality First', desc: 'The finest long-grain rice and tender hormone-free meat.' },
            ].map((item, idx) => (
              <div key={idx} className="p-8 bg-neutral-50 rounded-2xl hover:bg-white hover:shadow-2xl hover:shadow-gray-200 transition-all group border border-transparent hover:border-gray-100">
                <div className="w-14 h-14 bg-red-50 rounded-xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110">
                  <div className="animate-subtle-bounce">
                    {item.icon}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Signature Dishes Preview */}
      <section className="py-24 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div className="max-w-xl">
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 text-left">Our Signature Creations</h2>
              <p className="text-gray-600 text-left">Explore the dishes that made us famous. Each bite is a journey through Indian history.</p>
            </div>
            <Link to="/menu" className="flex items-center gap-2 text-royal-red font-bold hover:gap-4 transition-all">
              View Full Menu <ChevronRight size={20} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {signatureDishes.slice(0, 3).map((dish) => (
              <div key={dish.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 group">
                <div className="relative h-64 overflow-hidden">
                  <img src={dish.image} alt={dish.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full shadow-lg font-bold text-royal-red">
                    ₹{dish.price}
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-3">{dish.name}</h3>
                  <p className="text-gray-600 text-sm mb-6 line-clamp-2">{dish.description}</p>
                  <Link to="/menu" className="w-full block text-center py-3 border-2 border-royal-red text-royal-red font-bold rounded-xl hover:bg-royal-red hover:text-white transition-all">
                    Order This Dish
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-royal-red text-white overflow-hidden relative">
        <div className="absolute -top-20 -left-20 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-saffron/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Loved by Our Community</h2>
            <div className="w-24 h-1.5 bg-saffron mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS.map((review) => (
              <div key={review.id} className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/10 hover:bg-white/15 transition-all">
                <div className="flex gap-1 mb-6">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} size={18} fill="#FF9933" className="text-saffron" />
                  ))}
                </div>
                <p className="text-lg italic mb-8 font-light leading-relaxed">"{review.text}"</p>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-saffron">{review.author}</span>
                  <span className="text-xs text-white/50">{review.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* App CTA */}
      <section className="py-20 bg-saffron overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="flex-1 space-y-6">
              <h2 className="text-4xl md:text-6xl font-black text-royal-red">Craving Royalty?</h2>
              <p className="text-xl text-royal-red/80 font-medium">Get exclusive discounts when you order directly from our website.</p>
              <div className="flex gap-4">
                 <Link to="/menu" className="px-8 py-4 bg-royal-red text-white rounded-xl font-bold text-lg hover:scale-105 transition-all shadow-lg">Start My Order</Link>
                 <Link to="/contact" className="px-8 py-4 bg-white text-royal-red rounded-xl font-bold text-lg hover:scale-105 transition-all shadow-lg">Visit Us Today</Link>
              </div>
            </div>
            <div className="flex-1 relative">
                <div className="bg-royal-red/10 rounded-full p-12">
                   <img 
                    src="https://images.unsplash.com/photo-1543353071-087092ec393a?auto=format&fit=crop&q=80&w=800" 
                    alt="Food App" 
                    className="rounded-3xl shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500"
                   />
                </div>
            </div>
          </div>
        </div>
      </section>

      <style>{`
        @keyframes subtle-zoom {
          from { transform: scale(1.05); }
          to { transform: scale(1); }
        }
        .animate-subtle-zoom {
          animation: subtle-zoom 20s infinite alternate ease-in-out;
        }
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in-up {
          animation: fade-in-up 1s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default Home;
