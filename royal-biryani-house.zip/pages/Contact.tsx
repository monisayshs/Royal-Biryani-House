
import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, MessageSquare, Calendar, Users, CheckCircle2, ArrowLeft } from 'lucide-react';

const Contact: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    guests: '2',
    requests: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      // Reset form would normally happen here or after closing success
    }, 1500);
  };

  const resetForm = () => {
    setIsSuccess(false);
    setFormData({
      name: '',
      email: '',
      phone: '',
      date: '',
      time: '',
      guests: '2',
      requests: ''
    });
  };

  return (
    <div className="pt-20">
      <section className="bg-royal-red py-24 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold mb-6">Reservations & Contact</h1>
          <p className="text-xl text-saffron font-light max-w-2xl mx-auto italic">
            Secure your royal seat or reach out for inquiries. We look forward to serving you.
          </p>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-16">
            {/* Contact Info & Hours */}
            <div className="lg:w-1/3 space-y-12">
              <div>
                <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
                <div className="space-y-8">
                  <div className="flex items-start gap-5 group">
                    <div className="w-12 h-12 bg-red-50 text-royal-red rounded-xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110">
                      <Phone size={24} />
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">Call Us Directly</p>
                      <p className="text-xl font-bold text-gray-900">+91 98765 43210</p>
                      <p className="text-sm text-gray-500">For instant bookings & takeaway</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-5 group">
                    <div className="w-12 h-12 bg-red-50 text-royal-red rounded-xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110">
                      <Mail size={24} />
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">Email Inquiry</p>
                      <p className="text-xl font-bold text-gray-900">hello@royalbiryanihouse.com</p>
                      <p className="text-sm text-gray-500">Events & Catering queries</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-5 group">
                    <div className="w-12 h-12 bg-red-50 text-royal-red rounded-xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">Visit Our Branch</p>
                      <p className="text-xl font-bold text-gray-900 leading-tight">Jasola / Jamia Nagar, New Delhi</p>
                      <p className="text-sm text-gray-500">Opposite District Center</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-8 bg-neutral-900 text-white rounded-[2rem] shadow-2xl relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-saffron/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
                 <div className="flex items-center gap-3 mb-6 relative z-10">
                    <Clock className="text-saffron" size={24} />
                    <h3 className="text-xl font-bold">Service Hours</h3>
                 </div>
                 <div className="space-y-4 relative z-10">
                    <div className="flex justify-between border-b border-white/10 pb-2">
                       <span className="text-gray-400">Monday - Friday</span>
                       <span className="font-bold">11:00 AM - 11:00 PM</span>
                    </div>
                    <div className="flex justify-between border-b border-white/10 pb-2">
                       <span className="text-gray-400">Saturday - Sunday</span>
                       <span className="font-bold">11:00 AM - 12:00 AM</span>
                    </div>
                 </div>
              </div>
            </div>

            {/* Table Booking Form */}
            <div className="lg:w-2/3">
              <div className="bg-neutral-50 p-8 md:p-14 rounded-[3rem] border border-gray-100 shadow-sm relative min-h-[600px] flex flex-col justify-center transition-all duration-500">
                {isSuccess ? (
                  <div className="text-center space-y-8 animate-fade-in-up">
                    <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle2 size={48} />
                    </div>
                    <h2 className="text-4xl font-bold text-gray-900">Table Reserved!</h2>
                    <p className="text-lg text-gray-600 max-w-md mx-auto">
                      Thank you, <span className="font-bold text-royal-red">{formData.name}</span>. Your reservation for <span className="font-bold">{formData.guests} guests</span> on <span className="font-bold">{formData.date}</span> at <span className="font-bold">{formData.time}</span> has been received. 
                      We've sent a confirmation to <span className="italic">{formData.email}</span>.
                    </p>
                    <button 
                      onClick={resetForm}
                      className="inline-flex items-center gap-2 text-royal-red font-bold hover:gap-4 transition-all"
                    >
                      <ArrowLeft size={20} /> Back to Contact
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="mb-10 flex items-center gap-4">
                      <div className="w-1.5 h-12 bg-royal-red"></div>
                      <div>
                        <h2 className="text-4xl font-bold">Book Your Table</h2>
                        <p className="text-gray-500">Reserve your royal dining experience online</p>
                      </div>
                    </div>
                    
                    <form className="space-y-6" onSubmit={handleSubmit}>
                      {/* Personal Info */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Full Name</label>
                          <input 
                            required
                            type="text" 
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Rahul Sharma"
                            className="w-full px-5 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red transition-all"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Email</label>
                          <input 
                            required
                            type="email" 
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="rahul@example.com"
                            className="w-full px-5 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red transition-all"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Phone</label>
                          <input 
                            required
                            type="tel" 
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="+91 98XXX XXXX"
                            className="w-full px-5 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red transition-all"
                          />
                        </div>
                      </div>

                      {/* Booking Details */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Select Date</label>
                          <div className="relative">
                            <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={18} />
                            <input 
                              required
                              type="date" 
                              name="date"
                              value={formData.date}
                              onChange={handleInputChange}
                              className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red transition-all"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Time Slot</label>
                          <div className="relative">
                            <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={18} />
                            <select 
                              required
                              name="time"
                              value={formData.time}
                              onChange={handleInputChange}
                              className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red appearance-none transition-all"
                            >
                              <option value="">Choose Time</option>
                              <option value="12:00 PM">12:00 PM</option>
                              <option value="01:00 PM">01:00 PM</option>
                              <option value="02:00 PM">02:00 PM</option>
                              <option value="07:00 PM">07:00 PM</option>
                              <option value="08:00 PM">08:00 PM</option>
                              <option value="09:00 PM">09:00 PM</option>
                              <option value="10:00 PM">10:00 PM</option>
                            </select>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">No. of Guests</label>
                          <div className="relative">
                            <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={18} />
                            <select 
                              required
                              name="guests"
                              value={formData.guests}
                              onChange={handleInputChange}
                              className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red appearance-none transition-all"
                            >
                              {[1, 2, 3, 4, 5, 6, 8, 10, '12+'].map(num => (
                                <option key={num} value={num}>{num} {num === 1 ? 'Guest' : 'Guests'}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Special Requests (Optional)</label>
                        <textarea 
                          name="requests"
                          value={formData.requests}
                          onChange={handleInputChange}
                          rows={3}
                          placeholder="e.g. Anniversary celebration, Extra spice, Window seat..."
                          className="w-full px-5 py-4 rounded-2xl bg-white border border-gray-200 focus:outline-none focus:ring-2 focus:ring-royal-red transition-all"
                        ></textarea>
                      </div>

                      <button 
                        type="submit"
                        disabled={isSubmitting}
                        className={`w-full py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-xl group ${
                          isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-royal-red text-white hover:bg-red-800 hover:shadow-red-900/20'
                        }`}
                      >
                        {isSubmitting ? (
                          <div className="flex items-center gap-3">
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                            Confirming...
                          </div>
                        ) : (
                          <>
                            Confirm Reservation <Send size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                          </>
                        )}
                      </button>
                      <p className="text-center text-xs text-gray-400 italic">
                        By clicking confirm, you agree to our reservation terms and policies.
                      </p>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-24 bg-neutral-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4">
           <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Visit Our Royal Abode</h2>
              <div className="w-24 h-1 bg-saffron mx-auto rounded-full"></div>
           </div>
           <div className="bg-white rounded-[3rem] overflow-hidden shadow-2xl border border-gray-100 flex flex-col md:flex-row h-auto md:h-[500px]">
              <div className="md:w-1/2 p-10 md:p-16 flex flex-col justify-center">
                 <h3 className="text-3xl font-bold mb-6">Our Location</h3>
                 <p className="text-gray-600 mb-10 leading-relaxed text-lg">
                    We are situated at the bustling intersection of Jasola and Jamia Nagar. Perfect for a family dinner or a quick takeaway on your way home.
                 </p>
                 <div className="flex flex-col gap-6 mb-10">
                    <div className="flex items-center gap-4 text-gray-700 font-medium">
                       <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center text-royal-red">
                         <MapPin size={20} />
                       </div>
                       New Delhi - 110025, Jasola
                    </div>
                    <div className="flex items-center gap-4 text-gray-700 font-medium">
                       <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center text-royal-red">
                        <MessageSquare size={20} />
                       </div>
                       Located near the Jasola Apollo Metro Station
                    </div>
                 </div>
                 <a 
                  href="https://maps.google.com" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="bg-neutral-900 text-white px-10 py-5 rounded-2xl font-bold inline-block text-center hover:bg-black transition-all shadow-lg hover:shadow-black/20"
                 >
                   Open in Google Maps
                 </a>
              </div>
              <div className="md:w-1/2 bg-gray-200 h-[300px] md:h-full relative overflow-hidden">
                 <img 
                    src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=800" 
                    alt="Map Location" 
                    className="w-full h-full object-cover grayscale opacity-80"
                 />
                 <div className="absolute inset-0 bg-royal-red/5"></div>
                 <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative">
                      <div className="absolute inset-0 bg-royal-red/30 rounded-full scale-150 animate-ping"></div>
                      <div className="relative bg-white p-6 rounded-full shadow-2xl">
                         <MapPin className="text-royal-red" size={48} />
                      </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
