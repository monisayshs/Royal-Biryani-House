
import React, { useState } from 'react';
import { MenuCategory } from '../types';
import { DISHES } from './constants';
import { Search, Plus } from 'lucide-react';

const Menu: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['All', ...Object.values(MenuCategory)];

  const filteredDishes = DISHES.filter(dish => {
    const matchesCategory = activeCategory === 'All' || dish.category === activeCategory;
    const matchesSearch = dish.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pt-20 min-h-screen bg-neutral-50">
      {/* Hero */}
      <div className="bg-royal-red py-20 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
          <h1 className="text-5xl font-bold mb-4">Explore Our Menu</h1>
          <p className="text-saffron italic text-lg max-w-2xl mx-auto">From Signature Dum Biryani to Classic Indian Curries, every dish is a royal treat.</p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="sticky top-20 z-30 bg-white shadow-sm py-6 border-b">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto no-scrollbar py-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`whitespace-nowrap px-6 py-2 rounded-full text-sm font-bold transition-all ${
                  activeCategory === cat 
                    ? 'bg-royal-red text-white' 
                    : 'bg-neutral-100 text-gray-600 hover:bg-neutral-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search your favorite dish..."
              className="w-full pl-12 pr-4 py-3 bg-neutral-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-royal-red transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Menu Grid */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        {filteredDishes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDishes.map((dish) => (
              <div key={dish.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group flex flex-col border border-gray-100">
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={dish.image} 
                    alt={dish.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                  />
                  {dish.isSignature && (
                    <div className="absolute top-4 left-4 bg-saffron text-royal-red text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-lg">
                      Signature
                    </div>
                  )}
                  <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-md text-royal-red px-4 py-1.5 rounded-full font-black text-lg shadow-sm">
                    ₹{dish.price}
                  </div>
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <h3 className="text-xl font-bold mb-2 group-hover:text-royal-red transition-colors">{dish.name}</h3>
                  <p className="text-gray-500 text-sm mb-6 flex-1">{dish.description}</p>
                  <button className="w-full bg-neutral-50 border-2 border-neutral-100 hover:border-royal-red hover:bg-royal-red hover:text-white text-royal-red font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2">
                    <Plus size={18} /> Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-gray-300 mb-4 flex justify-center"><Search size={64} /></div>
            <h3 className="text-2xl font-bold text-gray-500">No dishes found matching your search.</h3>
            <button onClick={() => {setActiveCategory('All'); setSearchQuery('')}} className="mt-4 text-royal-red font-bold underline">Clear filters</button>
          </div>
        )}
      </div>

      {/* Combo Section */}
      <section className="py-24 bg-neutral-900 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12 bg-royal-red rounded-[3rem] p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <div className="flex-1 space-y-6">
              <span className="text-saffron font-bold tracking-widest uppercase text-sm">Best Sellers</span>
              <h2 className="text-4xl md:text-5xl font-black">Royal Family Combo</h2>
              <p className="text-lg text-red-100 opacity-80 leading-relaxed">
                A massive feast featuring 1kg Special Mutton Biryani, Tandoori Platter, Choice of Curry, 4 Naans, and 4 Desserts. Perfect for 4-6 people.
              </p>
              <div className="text-3xl font-bold">₹1,999 <span className="text-lg line-through text-red-200 ml-2 font-normal">₹2,499</span></div>
              <button className="bg-white text-royal-red px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition-all">Order Combo Now</button>
            </div>
            <div className="flex-1">
              <img src="https://images.unsplash.com/photo-1596797038530-2c39fa20b6c2?auto=format&fit=crop&q=80&w=800" className="rounded-2xl rotate-2 shadow-2xl" alt="Combo meal" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Menu;
