
import { Dish, MenuCategory, Review } from '../types';

export const DISHES: Dish[] = [
  {
    id: '1',
    name: 'Special Mutton Biryani',
    description: 'Slow-cooked tender mutton with aromatic long-grain basmati rice and secret royal spices.',
    price: 450,
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&q=80&w=800',
    category: MenuCategory.BIRYANI,
    isSignature: true
  },
  {
    id: '2',
    name: 'Royal Chicken Dum Biryani',
    description: 'Our signature Hyderabadi style chicken biryani, served with raita and salan.',
    price: 320,
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&q=80&w=800',
    category: MenuCategory.BIRYANI,
    isSignature: true
  },
  {
    id: '3',
    name: 'Tandoori Platter',
    description: 'Assortment of Chicken Tikka, Malai Tikka, and Seekh Kebab grilled to perfection.',
    price: 580,
    image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&q=80&w=800',
    category: MenuCategory.TANDOORI,
    isSignature: true
  },
  {
    id: '4',
    name: 'Butter Chicken',
    description: 'Classic creamy tomato-based gravy with charcoal-grilled chicken chunks.',
    price: 380,
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&q=80&w=800',
    category: MenuCategory.CURRIES,
    isSignature: false
  },
  {
    id: '5',
    name: 'Galouti Kebab',
    description: 'Melt-in-your-mouth minced mutton kebabs seasoned with exotic spices.',
    price: 350,
    image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&q=80&w=800',
    category: MenuCategory.STARTERS,
    isSignature: true
  },
  {
    id: '6',
    name: 'Garlic Naan',
    description: 'Leavened bread baked in clay oven topped with fresh garlic and cilantro.',
    price: 60,
    image: 'https://images.unsplash.com/photo-1601050633647-81a35d377a8a?auto=format&fit=crop&q=80&w=800',
    category: MenuCategory.BREADS,
    isSignature: false
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'r1',
    author: 'Rahul Sharma',
    rating: 5,
    text: 'The most authentic Hyderabadi Biryani I have ever had in Delhi. The aroma itself is enough to make you hungry!',
    date: '2 days ago'
  },
  {
    id: 'r2',
    author: 'Priya Verma',
    rating: 5,
    text: 'Quick service and consistent taste. Their Butter Chicken is also highly recommended. Great place for families.',
    date: '1 week ago'
  },
  {
    id: 'r3',
    author: 'Aman Khan',
    rating: 4,
    text: 'A local favorite for a reason. Always fresh and piping hot. Perfect for office lunches in Jasola.',
    date: '3 days ago'
  }
];

export const GALLERY_IMAGES = [
  'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1585238342024-78d387f4a707?auto=format&fit=crop&q=80&w=800',
  'https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&q=80&w=800',
];
