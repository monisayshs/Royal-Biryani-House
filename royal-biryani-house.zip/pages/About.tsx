
import React from 'react';
import { Shield, Clock, Award, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative h-[60vh] flex items-center justify-center">
        <img 
          src="https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=1600" 
          alt="Restaurant Interior" 
          className="absolute inset-0 w-full h-full object-cover brightness-[0.4]"
        />
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-4">Our Story</h1>
          <p className="text-xl text-saffron uppercase tracking-widest font-medium">Royal Biryani House: A Royal Heritage</p>
        </div>
      </section>

      {/* Story Content */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <h2 className="text-4xl font-bold text-gray-900 mb-8 leading-tight">Authentic Heritage <br/> in Every Grain.</h2>
              <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
                <p>
                  Founded with a simple vision to bring the authentic flavors of Hyderabad to the bustling streets of New Delhi, Royal Biryani House has evolved from a small kitchen to a beloved local culinary landmark.
                </p>
                <p>
                  Our journey began in a family kitchen where the secrets of the 'Dum' cooking style were passed down through generations. Today, we stay true to those roots, using the same hand-picked whole spices and the meticulous preparation methods that define true royalty.
                </p>
                <p>
                  In the heart of Jasola and Jamia Nagar, we aren't just a restaurant; we are part of the community. Every plate we serve is a testament to our commitment to quality, tradition, and the smiles of our customers.
                </p>
              </div>
            </div>
            <div className="lg:w-1/2 grid grid-cols-2 gap-4">
              <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=600" className="rounded-2xl shadow-xl mt-8" alt="Ambiance" />
              <img src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=600" className="rounded-2xl shadow-xl" alt="Chef at work" />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-neutral-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Core Values</h2>
            <div className="w-24 h-1 bg-saffron mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { 
                icon: <Shield className="text-saffron mb-6" size={48} />, 
                title: 'Quality First', 
                desc: 'We source only the freshest produce and premium aged Basmati rice to ensure every meal is perfect.' 
              },
              { 
                icon: <Clock className="text-saffron mb-6" size={48} />, 
                title: 'Timely Service', 
                desc: 'Whether you dine-in or order online, we value your time. Speed meets quality in our kitchen.' 
              },
              { 
                icon: <Award className="text-saffron mb-6" size={48} />, 
                title: 'Consistent Taste', 
                desc: 'The same royal taste today, tomorrow, and forever. Our spice blends are our legacy.' 
              },
            ].map((value, idx) => (
              <div key={idx} className="text-center p-8 bg-white/5 rounded-3xl border border-white/10">
                <div className="flex justify-center">{value.icon}</div>
                <h3 className="text-2xl font-bold mb-4">{value.title}</h3>
                <p className="text-gray-400">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <p className="text-5xl font-black text-royal-red mb-2">10+</p>
                <p className="text-gray-500 uppercase tracking-widest text-xs font-bold">Years of Heritage</p>
              </div>
              <div>
                <p className="text-5xl font-black text-royal-red mb-2">50k+</p>
                <p className="text-gray-500 uppercase tracking-widest text-xs font-bold">Happy Customers</p>
              </div>
              <div>
                <p className="text-5xl font-black text-royal-red mb-2">4.8</p>
                <p className="text-gray-500 uppercase tracking-widest text-xs font-bold">Average Rating</p>
              </div>
              <div>
                <p className="text-5xl font-black text-royal-red mb-2">30+</p>
                <p className="text-gray-500 uppercase tracking-widest text-xs font-bold">Unique Recipes</p>
              </div>
           </div>
        </div>
      </section>

      {/* Call to action */}
      <section className="py-24 bg-saffron">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-royal-red mb-8 leading-tight">Ready to Taste the Tradition?</h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/menu" className="px-10 py-4 bg-royal-red text-white font-bold rounded-full hover:shadow-2xl transition-all">Explore Our Menu</Link>
            <Link to="/contact" className="px-10 py-4 bg-white text-royal-red font-bold rounded-full hover:shadow-2xl transition-all">Visit Us Today</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
