
import React from 'react';
import { GALLERY_IMAGES } from './constants';
import { Instagram, Share2 } from 'lucide-react';

const Gallery: React.FC = () => {
  return (
    <div className="pt-20">
      <section className="bg-neutral-50 py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-20">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">A Feast for Your Eyes</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">Take a glimpse into our kitchen and dining experience. Every shot captures the essence of our passion for food.</p>
          </div>

          <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
            {GALLERY_IMAGES.map((img, idx) => (
              <div key={idx} className="relative group overflow-hidden rounded-3xl break-inside-avoid shadow-sm hover:shadow-2xl transition-all duration-500 cursor-pointer">
                <img 
                  src={img} 
                  alt={`Gallery item ${idx}`} 
                  className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-8">
                  <div className="text-white">
                    <p className="font-bold text-lg mb-1">Authentic Moment</p>
                    <p className="text-sm text-gray-300">Royal Biryani House Heritage</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-24 text-center bg-white p-12 rounded-[3rem] shadow-xl border border-gray-100">
            <h2 className="text-3xl font-bold mb-4">Loved our experience?</h2>
            <p className="text-gray-600 mb-8 max-w-lg mx-auto">Tag us in your photos for a chance to be featured and win a royal meal voucher!</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
               <a href="#" className="flex items-center justify-center gap-3 bg-gradient-to-tr from-yellow-600 via-red-600 to-purple-700 text-white px-8 py-3 rounded-xl font-bold hover:scale-105 transition-all">
                  <Instagram size={20} /> Follow us on Instagram
               </a>
               <button className="flex items-center justify-center gap-3 bg-neutral-100 text-gray-800 px-8 py-3 rounded-xl font-bold hover:bg-neutral-200 transition-all">
                  <Share2 size={20} /> Share Your Experience
               </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Gallery;
