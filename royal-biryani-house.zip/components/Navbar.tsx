
import React, { useState, useEffect } from 'react';
// Fix: Import Link and useLocation from react-router-dom
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingBag } from 'lucide-react';
import Logo from './Logo';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Menu', path: '/menu' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center group">
            <Logo isLight={!isScrolled} />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => {
              const active = isActive(link.path);
              return (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`relative text-sm transition-all duration-300 py-1 ${
                    active 
                      ? isScrolled ? 'text-royal-red font-bold' : 'text-saffron font-bold'
                      : isScrolled ? 'text-gray-700 hover:text-royal-red font-medium' : 'text-white hover:text-saffron font-medium'
                  }`}
                >
                  {link.name}
                  <span className={`absolute bottom-0 left-0 h-0.5 bg-current transition-all duration-300 ${active ? 'w-full' : 'w-0'}`} />
                </Link>
              );
            })}
            <Link 
              to="/menu"
              className="bg-royal-red text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-red-800 transition-all transform hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              Order Now <ShoppingBag size={16} />
            </Link>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden flex items-center gap-4">
             <Link to="/menu" className={isScrolled ? 'text-royal-red' : 'text-white'}>
                <ShoppingBag size={24} />
             </Link>
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className={isScrolled ? 'text-gray-800' : 'text-white'}
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 bg-white z-40 transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) transform ${isOpen ? 'translate-x-0' : 'translate-x-full'} md:hidden`}>
        <div className="flex flex-col items-center justify-center h-full space-y-8 p-6">
           <button 
              onClick={() => setIsOpen(false)}
              className="absolute top-6 right-6 text-gray-800"
              aria-label="Close menu"
            >
              <X size={32} />
            </button>
          <Logo className="h-16 mb-8" />
          {navLinks.map((link) => {
            const active = isActive(link.path);
            return (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`text-3xl font-serif transition-colors relative ${active ? 'text-royal-red font-black' : 'text-gray-800 font-bold'}`}
              >
                {link.name}
                {active && <span className="absolute -bottom-2 left-0 w-full h-1 bg-saffron rounded-full" />}
              </Link>
            );
          })}
          <Link 
            to="/menu"
            onClick={() => setIsOpen(false)}
            className="bg-royal-red text-white px-10 py-4 rounded-full text-lg font-semibold w-full text-center shadow-lg active:scale-95 transition-transform"
          >
            Order Now
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
