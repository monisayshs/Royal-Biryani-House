
import React from 'react';
// Fix: Import Link from react-router-dom
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail, Clock } from 'lucide-react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-900 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="space-y-6">
            <Link to="/" className="inline-block">
              <Logo isLight={true} className="h-12" />
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              Authentic Hyderabadi flavors in the heart of New Delhi. We bring the legacy of premium biryani to your table with passion and tradition.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-saffron transition-colors text-white">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-saffron transition-colors text-white">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-saffron transition-colors text-white">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><Link to="/" className="text-gray-400 hover:text-saffron transition-colors text-sm">Home</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-saffron transition-colors text-sm">Our Story</Link></li>
              <li><Link to="/menu" className="text-gray-400 hover:text-saffron transition-colors text-sm">Menu & Delivery</Link></li>
              <li><Link to="/gallery" className="text-gray-400 hover:text-saffron transition-colors text-sm">Gallery</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-saffron transition-colors text-sm">Book a Table</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="text-saffron flex-shrink-0" size={18} />
                <span className="text-gray-400 text-sm">Main Road, Jasola, Near Jamia Nagar, New Delhi - 110025</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="text-saffron flex-shrink-0" size={18} />
                <span className="text-gray-400 text-sm">+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="text-saffron flex-shrink-0" size={18} />
                <span className="text-gray-400 text-sm">hello@deliciousbiryani.com</span>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div>
            <h4 className="text-lg font-bold mb-6">Opening Hours</h4>
            <ul className="space-y-4">
              <li className="flex justify-between items-center text-sm">
                <span className="text-gray-400">Mon - Fri</span>
                <span className="text-white">11:00 AM - 11:00 PM</span>
              </li>
              <li className="flex justify-between items-center text-sm">
                <span className="text-gray-400">Sat - Sun</span>
                <span className="text-white">11:00 AM - 12:00 AM</span>
              </li>
              <li className="flex items-center gap-3 mt-4 text-xs text-saffron uppercase tracking-widest font-bold">
                <Clock size={14} /> Available for Online Delivery
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-xs">
            © {new Date().getFullYear()} Delicious Biryani. All rights reserved.
          </p>
          <p className="text-gray-500 text-xs italic">
            Developed with love for Indian Heritage.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
