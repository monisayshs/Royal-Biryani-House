
import React from 'react';

interface LogoProps {
  className?: string;
  isLight?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = "h-10", isLight = false }) => {
  const primaryColor = isLight ? "#FFFFFF" : "#8B0000"; // Deep Maroon / Royal Red
  const accentColor = "#FF9933"; // Saffron

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <div className="relative h-full aspect-square flex items-center justify-center">
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="h-full w-auto drop-shadow-sm transition-transform duration-500 group-hover:scale-105"
        >
          {/* Stylized Steam - Minimal & Elegant */}
          <path
            d="M24 14C24 14 22 10 24 8C26 6 24 4 24 4"
            stroke={accentColor}
            strokeWidth="2"
            strokeLinecap="round"
            className="animate-pulse opacity-70"
          />
          <path
            d="M32 16C32 16 30 11 32 9C34 7 32 5 32 5"
            stroke={accentColor}
            strokeWidth="2"
            strokeLinecap="round"
            style={{ animationDelay: "0.2s" }}
            className="animate-pulse"
          />
          <path
            d="M40 14C40 14 38 10 40 8C42 6 40 4 40 4"
            stroke={accentColor}
            strokeWidth="2"
            strokeLinecap="round"
            style={{ animationDelay: "0.4s" }}
            className="animate-pulse opacity-70"
          />
          
          {/* Modern Flat Handi Body */}
          <path
            d="M14 36C14 29.37 19.37 24 26 24H38C44.63 24 50 29.37 50 36V46C50 51.52 45.52 56 40 56H24C18.48 56 14 51.52 14 46V36Z"
            fill={primaryColor}
          />
          
          {/* Minimal Lid Rim */}
          <rect x="12" y="24" width="40" height="4" rx="2" fill={accentColor} />
          
          {/* Royal Emblem Detail (Crown/Diamond) */}
          <path
            d="M32 38L35 42H29L32 38Z"
            fill={isLight ? "#8B0000" : "#FFFFFF"}
            opacity="0.9"
          />
        </svg>
      </div>
      
      <div className="flex flex-col justify-center">
        <span 
          className={`text-[9px] tracking-[0.45em] font-black uppercase mb-0.5 leading-none ${
            isLight ? 'text-white/70' : 'text-gray-400'
          }`}
          style={{ fontFamily: "'Inter', sans-serif" }}
        >
          Royal
        </span>
        <span 
          className={`text-xl font-bold tracking-tight leading-none ${
            isLight ? 'text-white' : 'text-royal-red'
          }`}
          style={{ fontFamily: "'Playfair Display', serif" }}
        >
          BIRYANI HOUSE
        </span>
      </div>
    </div>
  );
};

export default Logo;
